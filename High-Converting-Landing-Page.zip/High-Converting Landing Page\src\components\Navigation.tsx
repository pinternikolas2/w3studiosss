import { Menu, X } from 'lucide-react';
import { useState } from 'react';

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const menuItems = [
    { href: '#sluzby', label: 'SLUŽBY' },
    { href: '#portfolio', label: 'PORTFOLIO' },
    { href: '#kontakt', label: 'KONTAKT' }
  ];

  return (
    <nav className="border-b border-[#333] bg-[#050505] sticky top-0 z-50">
      <div className="max-w-[1400px] mx-auto px-8 py-6 flex items-center justify-between">
        {/* Logo */}
        <div className="text-white font-bold tracking-tight" style={{ fontFamily: 'Inter, sans-serif', fontSize: '1.5rem' }}>
          W3STUDIO
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden md:flex items-center gap-12">
          {menuItems.map((item) => (
            <a 
              key={item.href}
              href={item.href} 
              className="text-[#999] hover:text-white transition-colors"
              style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.9rem' }}
            >
              {item.label}
            </a>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          className="md:hidden text-white p-2 hover:text-[#007AFF] transition-colors"
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-[#333] bg-[#050505]">
          <div className="px-8 py-4 flex flex-col gap-4">
            {menuItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setIsMenuOpen(false)}
                className="text-[#999] hover:text-white transition-colors py-2"
                style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.9rem' }}
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}