import { useState } from 'react';

import { toast } from 'sonner@2.0.3';

export function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission for Vercel deployment prototype
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Zpráva odeslána! Ozveme se vám co nejdříve.');
      setFormData({ name: '', email: '', phone: '', message: '' });
    } catch (error) {
      toast.error('Něco se pokazilo. Zkuste to prosím znovu.');
      console.error('Error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="kontakt" className="min-h-[70vh] flex items-center">
      <div className="max-w-[1400px] mx-auto px-8 py-20 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
          {/* Left Side - Big Text */}
          <div>
            <h2
              className="text-white mb-4"
              style={{
                fontFamily: 'Inter, sans-serif',
                fontWeight: 800,
                fontSize: 'clamp(1.75rem, 5vw, 3rem)',
                letterSpacing: '-0.02em',
                lineHeight: '1.2'
              }}
            >
              Máte otázku<br />nebo zájem o spolupráci?
            </h2>
            <p
              className="text-[#999]"
              style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: '0.95rem',
                lineHeight: '1.7'
              }}
            >
              Ať už budujete osobní značku, firmu nebo máte nápad, který si zaslouží pozornost – jsme tu pro vás. Stačí pár řádků ve formuláři a ozveme se zpět.
            </p>
          </div>

          {/* Right Side - Contact Form */}
          <div>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name Field */}
              <div>
                <label
                  htmlFor="name"
                  className="block text-[#999] mb-2"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.9rem'
                  }}
                >
                  Vaše jméno a příjmení*
                </label>
                <input
                  type="text"
                  id="name"
                  required
                  placeholder="Jméno a příjmení"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-transparent border border-[#333] text-white px-4 py-3 focus:border-[#007AFF] focus:outline-none transition-colors placeholder:text-[#666]"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.95rem'
                  }}
                />
              </div>

              {/* Email Field */}
              <div>
                <label
                  htmlFor="email"
                  className="block text-[#999] mb-2"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.9rem'
                  }}
                >
                  Váš e-mail*
                </label>
                <input
                  type="email"
                  id="email"
                  required
                  placeholder="E-mail"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-transparent border border-[#333] text-white px-4 py-3 focus:border-[#007AFF] focus:outline-none transition-colors placeholder:text-[#666]"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.95rem'
                  }}
                />
              </div>

              {/* Phone Field */}
              <div>
                <label
                  htmlFor="phone"
                  className="block text-[#999] mb-2"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.9rem'
                  }}
                >
                  Vaše telefonní číslo*
                </label>
                <input
                  type="tel"
                  id="phone"
                  required
                  placeholder="Telefon"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-transparent border border-[#333] text-white px-4 py-3 focus:border-[#007AFF] focus:outline-none transition-colors placeholder:text-[#666]"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.95rem'
                  }}
                />
              </div>

              {/* Message Field */}
              <div>
                <label
                  htmlFor="message"
                  className="block text-[#999] mb-2"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.9rem'
                  }}
                >
                  Vaše zpráva*
                </label>
                <textarea
                  id="message"
                  required
                  rows={5}
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full bg-transparent border border-[#333] text-white px-4 py-3 focus:border-[#007AFF] focus:outline-none transition-colors resize-none placeholder:text-[#666]"
                  style={{
                    fontFamily: 'JetBrains Mono, monospace',
                    fontSize: '0.95rem'
                  }}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#007AFF] text-white py-4 hover:bg-[#0066DD] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  fontFamily: 'Inter, sans-serif',
                  fontWeight: 700,
                  fontSize: '1rem',
                  letterSpacing: '0.05em'
                }}
              >
                {isSubmitting ? 'ODESÍLÁM...' : 'ODESLAT ZPRÁVU'}
              </button>
            </form>
          </div>
        </div>

        {/* UNIFIED FOOTER */}
        <div className="border-t border-[#333] pt-12">
          {/* Three Columns */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8">
            {/* Column 1: Brand */}
            <div>
              <div
                className="text-[#888]"
                style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: '12px',
                  lineHeight: '1.8'
                }}
              >
                W3. Digital Design & Development.
              </div>
            </div>

            {/* Column 2: Legal Info */}
            <div>
              <div
                className="text-[#888]"
                style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: '12px',
                  lineHeight: '1.8'
                }}
              >
                <div>Provozovatel: Nikolas Pintér</div>
                <div>Opletalova 793/8</div>
                <div>708 00 Ostrava - Poruba</div>
                <div className="mt-3">IČO: 08299722</div>
                <div>Fyzická osoba zapsaná v živnostenském rejstříku.</div>
              </div>
            </div>

            {/* Column 3: Contact */}
            <div>
              <div
                className="text-[#888]"
                style={{
                  fontFamily: 'JetBrains Mono, monospace',
                  fontSize: '12px',
                  lineHeight: '1.8'
                }}
              >
                <div>Napište nám:</div>
                <a
                  href="mailto:info@w3studio.cz"
                  className="hover:text-white transition-colors"
                >
                  info@w3studio.cz
                </a>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="pt-6 flex flex-col md:flex-row justify-center md:justify-between items-center gap-4">
            <div
              className="text-[#888]"
              style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: '12px'
              }}
            >
              © 2025 W3studio. Všechna práva vyhrazena.
            </div>

            <a
              href="/zasady-ochrany-osobnich-udaju"
              className="text-[#888] hover:text-white transition-colors"
              style={{
                fontFamily: 'JetBrains Mono, monospace',
                fontSize: '12px'
              }}
            >
              Zásady ochrany osobních údajů
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}