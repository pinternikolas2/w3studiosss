import { ExternalLink } from 'lucide-react';
import futurefitScreenshot from 'figma:asset/d5aff0361d08f9ecf0a2734776ee0b5cc0d8ff06.png';

export function PortfolioSection() {
  const projects = [
    {
      name: "Futurefit",
      description: "Web s kontaktním formulářem",
      url: "https://futurefit.cz/",
      image: futurefitScreenshot
    }
  ];

  return (
    <section id="portfolio" className="border-b border-[#333]">
      <div className="max-w-[1400px] mx-auto px-8 py-20">
        {/* Section Label */}
        <div 
          className="text-[#666] mb-16"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            letterSpacing: '0.1em'
          }}
        >
          VYBRANÁ PRÁCE (2024-2025)
        </div>

        {/* Projects */}
        <div className="space-y-24">
          {projects.map((project, index) => (
            <div key={index} className="group">
              {/* MacBook Mockup */}
              <div className="relative mx-auto max-w-5xl">
                
                {/* Screen */}
                <div className="relative bg-[#2a2a2a] rounded-t-2xl p-4 border-2 border-[#333]" 
                  style={{ 
                    boxShadow: '0 -5px 20px rgba(0,0,0,0.3)'
                  }}>
                  {/* Display */}
                  <div className="relative bg-black rounded-lg overflow-hidden" style={{ aspectRatio: '16/10' }}>
                    {/* Screenshot */}
                    <img 
                      src={project.image}
                      alt={project.name}
                      className="w-full h-full object-cover object-top"
                    />
                    
                    {/* Screen Glare */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/5 via-transparent to-transparent pointer-events-none"></div>
                  </div>
                </div>

                {/* Keyboard/Base */}
                <div 
                  className="relative bg-gradient-to-b from-[#2a2a2a] to-[#1a1a1a] px-12 py-8 border-2 border-t-0 border-[#333]"
                  style={{ 
                    boxShadow: '0 25px 60px rgba(0,0,0,0.6)',
                    clipPath: 'polygon(3% 0%, 97% 0%, 100% 100%, 0% 100%)',
                    borderRadius: '0 0 12px 12px'
                  }}
                >
                  {/* Keyboard Keys */}
                  <div className="space-y-1.5 mb-6">
                    {/* Row 1 */}
                    <div className="flex gap-1.5">
                      {[...Array(14)].map((_, i) => (
                        <div key={i} className="flex-1 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                      ))}
                    </div>
                    {/* Row 2 */}
                    <div className="flex gap-1.5">
                      {[...Array(14)].map((_, i) => (
                        <div key={i} className="flex-1 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                      ))}
                    </div>
                    {/* Row 3 */}
                    <div className="flex gap-1.5">
                      {[...Array(13)].map((_, i) => (
                        <div key={i} className="flex-1 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                      ))}
                    </div>
                    {/* Row 4 - Spacebar */}
                    <div className="flex gap-1.5">
                      <div className="w-16 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                      <div className="flex-1 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                      <div className="w-16 h-8 bg-[#1a1a1a] rounded border border-[#333]/50"></div>
                    </div>
                  </div>
                  
                  {/* Trackpad */}
                  <div className="mx-auto w-2/5 h-24 bg-[#1f1f1f] rounded-xl border border-[#333]/50"></div>
                </div>
                
                {/* Shadow */}
                <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-[90%] h-24 bg-black/40 blur-3xl rounded-full -z-10"></div>
              </div>

              {/* Project Info */}
              <div className="mt-20 flex flex-col md:flex-row md:items-center md:justify-between gap-6">
                <div>
                  {/* Project Name */}
                  <h3 
                    className="text-white mb-2"
                    style={{ 
                      fontFamily: 'Inter, sans-serif', 
                      fontWeight: 800,
                      fontSize: '2rem',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {project.name}
                  </h3>
                  
                  {/* Description */}
                  <p 
                    className="text-[#999]"
                    style={{ 
                      fontFamily: 'JetBrains Mono, monospace', 
                      fontSize: '0.95rem'
                    }}
                  >
                    {project.description}
                  </p>
                </div>

                {/* CTA Button */}
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-white text-black hover:bg-[#007AFF] hover:text-white transition-all duration-300 group/btn whitespace-nowrap"
                  style={{ 
                    fontFamily: 'Inter, sans-serif', 
                    fontWeight: 700,
                    fontSize: '0.9rem',
                    letterSpacing: '0.05em'
                  }}
                >
                  PŘEJÍT NA WEB
                  <ExternalLink size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}