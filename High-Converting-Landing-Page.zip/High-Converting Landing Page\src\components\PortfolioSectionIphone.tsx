import { ExternalLink } from 'lucide-react';
import futurefitScreenshot from 'figma:asset/9feb0153babc3cdf0b8c90d6bea18f2df8e0c330.png';
import lukasScreenshot from 'figma:asset/3d4f70761d9a444c64088187fe77517355d63707.png';

export function PortfolioSectionIphone() {
  const projects = [
    {
      name: "Futurefit",
      description: "Web s kontaktním formulářem",
      url: "https://futurefit.cz/",
      image: futurefitScreenshot
    },
    {
      name: "Lukáš Dekýš",
      description: "Prezentační web pro fightera",
      url: "#",
      image: lukasScreenshot
    }
  ];

  return (
    <section id="portfolio" className="border-b border-[#333]">
      <div className="max-w-[1400px] mx-auto px-8 py-20">
        {/* Section Label */}
        <div 
          className="text-[#666] mb-16"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            letterSpacing: '0.1em'
          }}
        >
          VYBRANÁ PRÁCE (2024-2025)
        </div>

        {/* Projects */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          {projects.map((project, index) => (
            <div key={index} className="group">
              {/* iPhone Mockup with 3D */}
              <div className="relative mx-auto max-w-[280px]" style={{ perspective: '1000px' }}>
                {/* Background Glow */}
                <div className="absolute inset-0 bg-gradient-radial from-[#1a1a1a] via-[#0a0a0a] to-transparent rounded-full blur-3xl scale-150 opacity-60"></div>
                
                <div 
                  className="relative z-10"
                  style={{ 
                    transform: 'rotateY(-10deg) rotateX(3deg)',
                    transformStyle: 'preserve-3d'
                  }}
                >
                  {/* iPhone Body */}
                  <div 
                    className="relative bg-gradient-to-br from-[#3a3a3a] via-[#2a2a2a] to-[#1f1f1f] rounded-[2rem] p-2 border-[3px] border-[#4a4a4a]"
                    style={{ 
                      boxShadow: '0 30px 70px rgba(0,0,0,0.8), 0 0 0 1px rgba(255,255,255,0.15), inset 0 1px 1px rgba(255,255,255,0.2)',
                    }}
                  >
                    {/* Power Button */}
                    <div className="absolute -right-0.5 top-24 w-0.5 h-12 bg-[#555] rounded-l shadow-lg"></div>
                    
                    {/* Volume Buttons */}
                    <div className="absolute -left-0.5 top-20 w-0.5 h-6 bg-[#555] rounded-r shadow-lg"></div>
                    <div className="absolute -left-0.5 top-28 w-0.5 h-6 bg-[#555] rounded-r shadow-lg"></div>
                    
                    {/* Screen */}
                    <div className="relative bg-black rounded-[1.7rem] overflow-hidden aspect-[9/19.5]" style={{ boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.1)' }}>
                      {/* Dynamic Island */}
                      <div className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-5 bg-black rounded-full z-10 border border-[#222]"></div>
                      
                      {/* Screenshot */}
                      <img 
                        src={project.image}
                        alt={project.name}
                        className="w-full h-full object-cover object-top"
                      />
                      
                      {/* Screen Glare */}
                      <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent pointer-events-none"></div>
                    </div>
                  </div>
                  
                  {/* 3D Shadow */}
                  <div 
                    className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-[80%] h-32 bg-black/40 blur-3xl rounded-full"
                    style={{ transform: 'translateZ(-100px)' }}
                  ></div>
                </div>
              </div>

              {/* Project Info */}
              <div className="mt-12 text-center">
                <div>
                  {/* Project Name */}
                  <h3 
                    className="text-white mb-2"
                    style={{ 
                      fontFamily: 'Inter, sans-serif', 
                      fontWeight: 800,
                      fontSize: '1.5rem',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {project.name}
                  </h3>
                  
                  {/* Description */}
                  <p 
                    className="text-[#999] mb-6"
                    style={{ 
                      fontFamily: 'JetBrains Mono, monospace', 
                      fontSize: '0.85rem'
                    }}
                  >
                    {project.description}
                  </p>
                </div>

                {/* CTA Button */}
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 px-6 py-3 bg-white text-black hover:bg-[#007AFF] hover:text-white transition-all duration-300 group/btn"
                  style={{ 
                    fontFamily: 'Inter, sans-serif', 
                    fontWeight: 700,
                    fontSize: '0.85rem',
                    letterSpacing: '0.05em'
                  }}
                >
                  PŘEJÍT NA WEB
                  <ExternalLink size={16} className="group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}