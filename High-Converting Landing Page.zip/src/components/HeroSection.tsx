export function HeroSection() {
  return (
    <section className="min-h-[90vh] flex items-center border-b border-[#333]">
      <div className="max-w-[1400px] mx-auto px-8 py-20 w-full">
        {/* Massive Display Text */}
        <h1 
          className="text-white uppercase leading-[0.9] mb-8"
          style={{ 
            fontFamily: 'Inter, sans-serif', 
            fontWeight: 800,
            fontSize: 'clamp(3rem, 12vw, 8rem)',
            letterSpacing: '-0.02em'
          }}
        >
          DESIGN.<br />
          VÝVOJ.<br />
          SPRÁVA.
        </h1>

        {/* Monospace Subtext */}
        <p 
          className="text-[#999] max-w-2xl mb-12"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            lineHeight: '1.8'
          }}
        >
          W3studio. Design, vývoj a správa webů.
        </p>

        {/* CTA Button */}
        <a 
          href="#kontakt"
          className="inline-block border-2 border-white text-white px-8 py-4 hover:bg-white hover:text-[#050505] transition-all duration-300"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            fontWeight: 500
          }}
        >
          Zaslat poptávku
        </a>
      </div>
    </section>
  );
}