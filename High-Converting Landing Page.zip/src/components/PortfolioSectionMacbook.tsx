import { ExternalLink } from 'lucide-react';
import futurefitMockup from 'figma:asset/512f3b65d793a93ddcd1f56a3564cc49eb0b0d08.png';
import lukasMockup from 'figma:asset/e190393154827d0eb21d0aab9e26c21a36822338.png';

export function PortfolioSectionMacbook() {
  const projects = [
    {
      name: "Lukáš Dekýš",
      description: "Prezentační web pro fightera",
      url: "#",
      mockup: lukasMockup
    },
    {
      name: "Futurefit",
      description: "Web s kontaktním formulářem",
      url: "https://futurefit.cz/",
      mockup: futurefitMockup
    }
  ];

  return (
    <section id="portfolio" className="border-b border-[#333]">
      <div className="max-w-[1400px] mx-auto px-8 py-20">
        {/* Section Label */}
        <div 
          className="text-[#666] mb-16"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            letterSpacing: '0.1em'
          }}
        >
          NAŠE PRÁCE
        </div>

        {/* Projects */}
        <div className="grid grid-cols-1 gap-24">
          {projects.map((project, index) => (
            <div key={index} className="group">
              {/* MacBook Mockup */}
              <div className="relative mx-auto max-w-[900px]">
                {/* Background Glow */}
                <div className="absolute inset-0 bg-gradient-radial from-[#1a1a1a] via-[#0a0a0a] to-transparent rounded-full blur-3xl scale-125 opacity-40"></div>
                
                {/* Mockup Image */}
                <div className="relative z-10">
                  <img 
                    src={project.mockup}
                    alt={`${project.name} MacBook Mockup`}
                    className="w-full h-auto drop-shadow-2xl"
                  />
                </div>
              </div>

              {/* Project Info */}
              <div className="mt-16 text-center">
                <div>
                  {/* Project Name */}
                  <h3 
                    className="text-white mb-2"
                    style={{ 
                      fontFamily: 'Inter, sans-serif', 
                      fontWeight: 800,
                      fontSize: '2rem',
                      letterSpacing: '-0.01em'
                    }}
                  >
                    {project.name}
                  </h3>
                  
                  {/* Description */}
                  <p 
                    className="text-[#999] mb-8"
                    style={{ 
                      fontFamily: 'JetBrains Mono, monospace', 
                      fontSize: '0.95rem'
                    }}
                  >
                    {project.description}
                  </p>
                </div>

                {/* CTA Button */}
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 px-8 py-4 bg-white text-black hover:bg-[#007AFF] hover:text-white transition-all duration-300 group/btn"
                  style={{ 
                    fontFamily: 'Inter, sans-serif', 
                    fontWeight: 700,
                    fontSize: '0.9rem',
                    letterSpacing: '0.05em'
                  }}
                >
                  PŘEJÍT NA WEB
                  <ExternalLink size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}