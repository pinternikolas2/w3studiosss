import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "Uvidím, jak bude web vypadat, než začnete programovat?",
      answer: "Rozhodně. Nekupujete zajíce v pytli. Design nejprve navrhneme v profesionálním nástroji Figma. Uvidíte přesný vizuální návrh (prototyp), který spolu vyladíme. Teprve až když jste s designem 100% spokojeni, začínáme psát kód."
    },
    {
      question: "Na jaké technologii weby stavíte? Používáte šablony?",
      answer: "Levné šablony, které zpomalují web, u nás nenajdete. Vše píšeme \"na míru\" pomocí moderního a čistého kódu (HTML5, CSS3, JavaScript). Pro náročnější aplikace využíváme technologie jako React nebo Next.js. Díky tomu je web bleskurychlý, bezpečný a plně ve vaší režii."
    },
    {
      question: "Budu si moci obsah na webu upravovat sám?",
      answer: "Máte dvě možnosti. Buď vám web nasadíme na redakční systém WordPress, kde si můžete sami měnit texty a fotky. Nebo využijete naši službu Správa, kdy web běží na našem super-rychlém hostingu a jakoukoliv změnu (texty, akce, fotky) uděláme obratem za vás. Vy se tak nemusíte učit s žádným systémem."
    },
    {
      question: "Jak dlouho trvá vytvoření webu?",
      answer: "Díky našim efektivním procesům a využití AI nástrojů jsme rychlejší než běžné agentury. Jednoduchý prezentační web dokážeme spustit už do 7 dnů od dodání podkladů. Rozsáhlejší projekty a e-shopy obvykle trvají 2–4 týdny. Vždy vám dáme závazný termín předem."
    },
    {
      question: "Co přesně znamená ta \"AI Chat Podpora\"?",
      answer: "Je to chytrý asistent, kterého vložíme na váš web. Není to \"hloupý automat\", ale AI, kterou naučíme informace o vaší firmě (ceník, služby, otevírací dobu). Dokáže pak vašim návštěvníkům odpovídat na dotazy 24 hodin denně, a dokonce od nich získá telefonní číslo nebo email, abyste se jim mohli ozvat zpět."
    },
    {
      question: "Bude web po dokončení mým majetkem?",
      answer: "Ano. Nejsme pronajímatelé webů. Po doplacení ceny se stáváte 100% vlastníkem zdrojového kódu i designu. Pokud se v budoucnu rozhodnete přejít jinam, nikdo vás nebude držet – web je váš."
    },
    {
      question: "Co když se na webu něco pokazí?",
      answer: "Pokud využíváte naši službu Správa, o nic se nestaráte – opravy řešíme my okamžitě a zdarma v rámci paušálu. Pokud web spravujete sami, poskytujeme na naše dílo standardní záruku a jsme vám k dispozici pro případné servisní zásahy."
    }
  ];

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <>
      {/* FAQ Schema Markup for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": faq.answer
              }
            }))
          })
        }}
      />

      <section id="faq" className="border-b border-[#333]">
        <div className="max-w-[1000px] mx-auto px-8 py-20">
          {/* Section Label */}
          <div 
            className="text-[#666] mb-4"
            style={{ 
              fontFamily: 'JetBrains Mono, monospace', 
              fontSize: '0.9rem',
              letterSpacing: '0.1em'
            }}
          >
            FAQ
          </div>

          {/* Section Title */}
          <h2 
            className="text-white mb-16"
            style={{ 
              fontFamily: 'Inter, sans-serif', 
              fontWeight: 800,
              fontSize: 'clamp(2rem, 5vw, 3rem)',
              letterSpacing: '-0.02em',
              lineHeight: '1.1'
            }}
          >
            Často kladené dotazy
          </h2>

          {/* FAQ Accordion */}
          <div className="space-y-0">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className="border-t border-[#333] last:border-b last:border-[#333]"
              >
                <button
                  onClick={() => toggleAccordion(index)}
                  className="w-full py-6 flex items-start justify-between gap-6 text-left group hover:opacity-80 transition-opacity"
                >
                  {/* Question Number & Text */}
                  <div className="flex-1">
                    <span 
                      className="text-[#007AFF] mr-3"
                      style={{ 
                        fontFamily: 'JetBrains Mono, monospace',
                        fontSize: '0.85rem',
                        fontWeight: 600
                      }}
                    >
                      {String(index + 1).padStart(2, '0')}.
                    </span>
                    <span 
                      className="text-white"
                      style={{ 
                        fontFamily: 'Inter, sans-serif',
                        fontWeight: 700,
                        fontSize: '1.1rem',
                        letterSpacing: '-0.01em'
                      }}
                    >
                      {faq.question}
                    </span>
                  </div>

                  {/* Icon */}
                  <ChevronDown 
                    className={`text-[#666] transition-transform duration-300 flex-shrink-0 mt-1 ${
                      openIndex === index ? 'rotate-180' : ''
                    }`}
                    size={20}
                  />
                </button>

                {/* Answer */}
                <div 
                  className={`overflow-hidden transition-all duration-300 ${
                    openIndex === index ? 'max-h-96 pb-6' : 'max-h-0'
                  }`}
                >
                  <p 
                    className="text-[#999] pl-12 pr-8"
                    style={{ 
                      fontFamily: 'JetBrains Mono, monospace',
                      fontSize: '0.9rem',
                      lineHeight: '1.7'
                    }}
                  >
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
