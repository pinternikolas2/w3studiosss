import { ArrowRight, ChevronDown } from 'lucide-react';
import { useState } from 'react';

export function ServicesSection() {
  const [openService, setOpenService] = useState<number | null>(null);

  const services = [
    {
      number: "01",
      title: "DESIGN & UX",
      description: "Strategie a vizuální identita.",
      fullTitle: "Web, který z návštěvníků udělá zákazníky",
      content: "Nejde jen o to, aby byl web hezký. Musí být hlavně přehledný. Navrhneme ho tak, aby zákazník okamžitě pochopil, co děláte, proč jste nejlepší volba a kde najde telefonní číslo. Žádné zbytečnosti, které by ho rozptylovaly od poptávky.",
      features: [
        "Přehlednost: Zákazník najde, co hledá, do 3 vteřin.",
        "Důvěra: Profesionální vzhled, díky kterému nebudete vypadat jako amatéři.",
        "Funkčnost na mobilu: Web se bude ovládat skvěle i palcem na telefonu.",
        "Jasná tlačítka: Výrazné prvky, které navedou lidi k zavolání nebo objednání."
      ]
    },
    {
      number: "02",
      title: "VÝVOJ",
      description: "Kódování, rychlost, SEO.",
      fullTitle: "Rychlý a spolehlivý web, který Google miluje",
      content: "Znáte to, když se stránka načítá věčnost? Zákazník odejde ke konkurenci. My stavíme weby, které běží bleskově. Nepoužíváme pomalé šablony, ale píšeme kvalitní kód na míru. Díky tomu se váš web bude líbit nejen lidem, ale i vyhledávačům, jako je Google.",
      features: [
        "Blesková rychlost: Stránky se načítají okamžitě, nikdo nebude čekat.",
        "Technická kvalita: Vše funguje bez chyb na počítači, tabletu i mobilu.",
        "Lepší pozice: Google upřednostňuje rychlé a technicky správné weby.",
        "Připraveno k růstu: Až se vaše firma rozroste, web snadno rozšíříme."
      ]
    },
    {
      number: "03",
      title: "SPRÁVA",
      description: "Bezpečnost a aktualizace.",
      fullTitle: "Vy se věnujte práci, o techniku se postaráme my",
      content: "Webem to nekončí. Potřebuje aktualizace a zabezpečení, jinak přestane fungovat nebo ho napadnou viry. S naší správou to můžete pustit z hlavy. My hlídáme, aby vše běželo, zatímco vy jste na stavbě nebo na schůzce s klienty.",
      features: [
        "Klid: Nemusíte řešit žádné technické problémy ani aktualizace.",
        "Bezpečnost: Chráníme váš web před útoky a viry.",
        "Zálohování: I kdyby se cokoliv stalo, vaše data máme zálohovaná.",
        "Pomoc na telefonu: Když potřebujete něco změnit, stačí nám napsat."
      ]
    },
    {
      number: "04",
      title: "AI CHAT PODPORA",
      description: "Automatizace a inovace.",
      fullTitle: "Asistent, který odepisuje klientům, i když vy spíte",
      content: "Nestíháte zvedat telefony nebo odepisovat na e-maily hned? Nasadíme vám na web chytrý chat. Naučíme ho vaše ceny a služby, takže dokáže zákazníkům odpovědět za vás – klidně o půlnoci nebo o víkendu. Získá od nich kontakt a vy se ozvete, až budete mít čas.",
      features: [
        "Dostupnost 24/7: Vaše firma komunikuje nonstop, i o svátcích.",
        "Šetří váš čas: Odpovídá na časté dotazy (cena, termíny) za vás.",
        "Sběr kontaktů: Získá od zájemce jméno a telefon, abyste mu mohli zavolat.",
        "Chytré odpovědi: Není to hloupý automat, zákazník si popovídá skoro jako s člověkem."
      ]
    }
  ];

  const toggleService = (index: number) => {
    setOpenService(openService === index ? null : index);
  };

  return (
    <section id="sluzby" className="border-b border-[#333]">
      <div className="max-w-[1400px] mx-auto px-8 py-20">
        {/* Section Label */}
        <div 
          className="text-[#666] mb-4"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.9rem',
            letterSpacing: '0.1em'
          }}
        >
          SLUŽBY
        </div>

        {/* Hint text for mobile */}
        <div 
          className="text-[#666] mb-12 md:hidden"
          style={{ 
            fontFamily: 'JetBrains Mono, monospace', 
            fontSize: '0.85rem'
          }}
        >
          ↓ Klikněte na službu pro více informací
        </div>

        {/* Services List */}
        <div className="space-y-0">
          {services.map((service, index) => (
            <div key={index}>
              {/* Service Row */}
              <div 
                onClick={() => toggleService(index)}
                className="border-t border-[#333] py-8 grid grid-cols-12 gap-8 items-center hover:bg-white/[0.02] transition-colors cursor-pointer group"
              >
                {/* Number */}
                <div 
                  className="col-span-2 text-[#666] group-hover:text-white transition-colors"
                  style={{ 
                    fontFamily: 'JetBrains Mono, monospace', 
                    fontSize: '0.9rem'
                  }}
                >
                  {service.number}
                </div>

                {/* Title */}
                <div 
                  className="col-span-4 text-white"
                  style={{ 
                    fontFamily: 'Inter, sans-serif', 
                    fontWeight: 800,
                    fontSize: '1.5rem',
                    letterSpacing: '0.02em'
                  }}
                >
                  {service.title}
                </div>

                {/* Description */}
                <div 
                  className="col-span-5 text-[#999]"
                  style={{ 
                    fontFamily: 'JetBrains Mono, monospace', 
                    fontSize: '0.9rem'
                  }}
                >
                  {service.description}
                </div>

                {/* Arrow */}
                <div className="col-span-1 flex justify-end">
                  <ChevronDown 
                    className={`text-[#666] group-hover:text-white transition-all ${openService === index ? 'rotate-180' : ''}`}
                    size={24} 
                  />
                </div>
              </div>

              {/* Expanded Content */}
              {openService === index && (
                <div 
                  className="border-t border-[#333] py-8 px-8 bg-white/[0.01]"
                  style={{
                    animation: 'slideDown 0.3s ease-out'
                  }}
                >
                  <div className="max-w-[900px]">
                    {/* Full Title */}
                    <h3 
                      className="text-white mb-6"
                      style={{ 
                        fontFamily: 'Inter, sans-serif', 
                        fontWeight: 700,
                        fontSize: '1.8rem',
                        letterSpacing: '-0.01em'
                      }}
                    >
                      {service.fullTitle}
                    </h3>

                    {/* Content */}
                    <p 
                      className="text-[#999] mb-8 leading-relaxed"
                      style={{ 
                        fontFamily: 'JetBrains Mono, monospace', 
                        fontSize: '0.95rem'
                      }}
                    >
                      {service.content}
                    </p>

                    {/* Features */}
                    <div className="space-y-4">
                      {service.features.map((feature, featureIndex) => (
                        <div 
                          key={featureIndex}
                          className="text-[#999] pl-6 border-l-2 border-[#007AFF]"
                          style={{ 
                            fontFamily: 'JetBrains Mono, monospace', 
                            fontSize: '0.9rem'
                          }}
                        >
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </section>
  );
}